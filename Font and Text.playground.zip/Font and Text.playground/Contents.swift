/*:
 # What is this playground file
 Well, this file is just a normal interactive playground built-in attributes from the file that you just need to change from the attributes marked by the //: symbol
 # How to check what happens with the changes you made
 Well you could just run the code in the assistant editor and all the attributes you have will be updated once the newer code has been ran.
 
 # Purpose of this playground
 To show what interactive playgrounds can do that apps don't
 
 # Note
 We only provide some common properties, meaning to say that we don't give you full functionality of the attributes, however, it is possible for you to add the properties yourself
 
 */




import UIKit
import PlaygroundSupport


/*:
 # Frame size
 We allow you to customize the frame size according to what you want it to be, simply just change the attributes called frameWidth and frameHeight and the frame size will be updated to your customizations.
 */
let frameWidth : Int = 375
let frameHeight: Int = 667

let frame = CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight)



class ViewController : UIViewController {
    
    
    override func loadView() {
        let black = UIColor.black
        let white = UIColor.white
        let blue = UIColor.blue
        let green = UIColor.green
        let red = UIColor.red
        
        
        //MARK: Background color property
        
        let backgroundColor = black
        
        let view = UIView()
        let label = UILabel()
        
        
        let labelXPostition : Int = 107
        let labelYPostition : Int = 20
        let labelWidth : Int = 107
        let labelHeight : Int = 100
        let labelFont: String = "System"
        let labelSize: CGFloat = 71.0
        let labelTextColor = red
        let labelText : String = "By Jeff Lim"
        
 
        
        

        
        label.frame = CGRect(x: labelXPostition, y: labelYPostition, width: labelWidth, height: labelHeight)
        label.text = labelText
        label.textColor = labelTextColor
        label.font = UIFont(name: labelFont, size: labelSize)
        view.addSubview(label)
        
        view.backgroundColor = backgroundColor
        self.view = view
    }
}


let viewController = ViewController()
viewController.preferredContentSize = frame.size
PlaygroundPage.current.liveView = viewController
